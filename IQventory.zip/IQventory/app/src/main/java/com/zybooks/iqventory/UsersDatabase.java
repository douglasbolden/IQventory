package com.zybooks.iqventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

/**
 * User/Item Database SQLite Handler.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class UsersDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "user.db";

    private static UsersDatabase usersDb;

    /**
     * Function that returns a Singleton Object of the UsersDatabase.
     */
    public static UsersDatabase getInstance(Context context) {
        if (usersDb == null) {
            usersDb = new UsersDatabase(context);
        }

        return usersDb;
    }

    /**
     * Enumerator that sorts the Items in the grid.
     */
    public enum ItemSortOrder { ALPHABETIC, UPDATE_DESC, UPDATE_ASC }

    /**
     * Associates the context with the function UsersDatabase
     */
    public UsersDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /**
     * creates UserTable Class for storing users
     */
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_PHONE = "phone";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    /**
     * creates ItemDetailTable Class for storing items
     */
    private static final class ItemDetailTable {
        private static final String TABLE = "itemDetails";
        private static final String COL_ID = "_id";
        private static final String COL_AMOUNT = "amount";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_ITEM = "item";
        private static final String COL_IS_LOW = "is_low";

    }

    /**
     * onCreate Method starts when the user is here.
     * Specifies which layout to use.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create users table
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_USERNAME + " primary key, " +
                UserTable.COL_PHONE + " TEXT, " +
                UserTable.COL_PASSWORD + " TEXT)");

        // Create itemDetails table with foreign key that cascade deletes
        db.execSQL("create table " + UsersDatabase.ItemDetailTable.TABLE + " (" +
                UsersDatabase.ItemDetailTable.COL_ID + " integer primary key autoincrement, " +
                UsersDatabase.ItemDetailTable.COL_AMOUNT + ", " +
                UsersDatabase.ItemDetailTable.COL_DESCRIPTION + ", " +
                UsersDatabase.ItemDetailTable.COL_ITEM + ", " +
                UsersDatabase.ItemDetailTable.COL_IS_LOW + ", " +
                "foreign key(" + UsersDatabase.ItemDetailTable.COL_ITEM + ") references " +
                UsersDatabase.UserTable.TABLE + "(" + UsersDatabase.UserTable.COL_USERNAME + ") on delete cascade)");

        // Add some users
        User doug = new User("4233002190", "doug", "pass");
        ContentValues user1 = new ContentValues();
        user1.put(UserTable.COL_PHONE, User.getUserPhone());
        user1.put(UserTable.COL_USERNAME, User.getUserName());
        user1.put(UserTable.COL_PASSWORD, User.getUserPass());
        db.insert(UserTable.TABLE, null, user1);

        User kelly = new User("4232482957", "kelly", "pass");
        ContentValues user2 = new ContentValues();
        user2.put(UserTable.COL_PHONE, User.getUserPhone());
        user2.put(UserTable.COL_USERNAME, User.getUserName());
        user2.put(UserTable.COL_PASSWORD, User.getUserPass());
        db.insert(UserTable.TABLE, null, user2);

        User jerome = new User("4233002190", "jerome", "pass");
        ContentValues user3 = new ContentValues();
        user3.put(UserTable.COL_PHONE, User.getUserPhone());
        user3.put(UserTable.COL_USERNAME, User.getUserName());
        user3.put(UserTable.COL_PASSWORD, User.getUserPass());
        db.insert(UserTable.TABLE, null, user3);


        // Add some items
        Item cup = new Item(1, "Cup", "Used to hold liquids or other items.", 13,0);
        ContentValues item1 = new ContentValues();
        item1.put(ItemDetailTable.COL_ID, cup.getId());
        item1.put(ItemDetailTable.COL_ITEM, cup.getItem());
        item1.put(ItemDetailTable.COL_DESCRIPTION, cup.getDesc());
        item1.put(ItemDetailTable.COL_AMOUNT, cup.getQty());
        item1.put(ItemDetailTable.COL_IS_LOW, cup.getLow());
        db.insert(ItemDetailTable.TABLE, null, item1);

        Item penny = new Item(2, "Penny", "Used for the acquisition of other items.", 654,0);
        ContentValues item2 = new ContentValues();
        item2.put(ItemDetailTable.COL_ID, penny.getId());
        item2.put(ItemDetailTable.COL_ITEM, penny.getItem());
        item2.put(ItemDetailTable.COL_DESCRIPTION, penny.getDesc());
        item2.put(ItemDetailTable.COL_AMOUNT, penny.getQty());
        item2.put(ItemDetailTable.COL_IS_LOW, penny.getLow());
        db.insert(ItemDetailTable.TABLE, null, item2);

        Item pen = new Item(3, "Pen", "Used to write on writable surfaces.", 21,0);
        ContentValues item3 = new ContentValues();
        item3.put(ItemDetailTable.COL_ID, pen.getId());
        item3.put(ItemDetailTable.COL_ITEM, pen.getItem());
        item3.put(ItemDetailTable.COL_DESCRIPTION, pen.getDesc());
        item3.put(ItemDetailTable.COL_AMOUNT, pen.getQty());
        item3.put(ItemDetailTable.COL_IS_LOW, pen.getLow());
        db.insert(ItemDetailTable.TABLE, null, item3);

        Item ticket = new Item(4, "Lottery Tickets", "If you are lucky, you might win something from this.", 5,0);
        ContentValues item4 = new ContentValues();
        item4.put(ItemDetailTable.COL_ID, ticket.getId());
        item4.put(ItemDetailTable.COL_ITEM, ticket.getItem());
        item4.put(ItemDetailTable.COL_DESCRIPTION, ticket.getDesc());
        item4.put(ItemDetailTable.COL_AMOUNT, ticket.getQty());
        item4.put(ItemDetailTable.COL_IS_LOW, ticket.getLow());
        db.insert(ItemDetailTable.TABLE, null, item4);

        Item brainCells = new Item(5, "Brain Cells", "I am surprised that I have this many with the amount of sleep I am not getting.", 3,0);
        ContentValues item5 = new ContentValues();
        item5.put(ItemDetailTable.COL_ID, brainCells.getId());
        item5.put(ItemDetailTable.COL_ITEM, brainCells.getItem());
        item5.put(ItemDetailTable.COL_DESCRIPTION, brainCells.getDesc());
        item5.put(ItemDetailTable.COL_AMOUNT, brainCells.getQty());
        item5.put(ItemDetailTable.COL_IS_LOW, brainCells.getLow());
        db.insert(ItemDetailTable.TABLE, null, item5);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + UsersDatabase.ItemDetailTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            db.setForeignKeyConstraintsEnabled(true);
        }
    }

    public List<Item> getItems(ItemSortOrder order) {

        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String orderBy;

        switch (order) {
            case ALPHABETIC:
                orderBy = ItemDetailTable.COL_ITEM + " collate nocase";
                break;
            case UPDATE_DESC:
                orderBy = ItemDetailTable.COL_AMOUNT + " desc";
                break;
            default:
                orderBy = ItemDetailTable.COL_AMOUNT + " asc";
                break;
        }

        String sql = "select * from " + ItemDetailTable.TABLE + " order by " + orderBy;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {

            do {
                Item item = new Item();
                item.setItem(cursor.getString(0));
                item.setDesc(cursor.getString(1));
                item.setQty(cursor.getInt(2));
                item.setLow(cursor.getInt(3));
                items.add(item);
            }
            while (cursor.moveToNext());
        }
        cursor.close();

        return items;
    }

    public boolean checkUser(EditText username) {
        String user = username.getText().toString();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + UserTable.TABLE +
                        " WHERE " + UserTable.COL_USERNAME + " = ?",
                new String[] {user});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean checkUserAndPass(EditText username, EditText password) {
        String user = username.getText().toString();
        String pass = password.getText().toString();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + UserTable.TABLE +
                        " WHERE " + UserTable.COL_USERNAME + " = ? AND " + UserTable.COL_PASSWORD + " = ?",
                new String[] {user, pass});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public void addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_PHONE, User.getUserPhone());
        values.put(UserTable.COL_USERNAME, User.getUserName());
        values.put(UserTable.COL_PASSWORD, User.getUserPass());
        db.insert(UserTable.TABLE, null, values);

    }

    public void updateUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_PHONE, User.getUserPhone());
        values.put(UserTable.COL_PASSWORD, User.getUserPass());
        db.update(UserTable.TABLE, values,
                UserTable.COL_USERNAME + " = ?", new String[] { User.getUserName() });

    }

    public void deleteUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UserTable.TABLE,
                UserTable.COL_USERNAME + " = ?", new String[] { User.getUserName() });

    }

    public boolean addItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemDetailTable.COL_ID, item.getId());
        values.put(ItemDetailTable.COL_ITEM, item.getItem());
        values.put(ItemDetailTable.COL_DESCRIPTION, item.getDesc());
        values.put(ItemDetailTable.COL_AMOUNT, item.getQty());
        values.put(ItemDetailTable.COL_IS_LOW, item.getLow());
        db.insert(ItemDetailTable.TABLE, null, values);

        return true;
    }

    public Item addItem(int itemId) {
        Item item = new Item(itemId);
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemDetailTable.COL_ID, item.getId());
        values.put(ItemDetailTable.COL_ITEM, item.getItem());
        values.put(ItemDetailTable.COL_DESCRIPTION, item.getDesc());
        values.put(ItemDetailTable.COL_AMOUNT, item.getQty());
        values.put(ItemDetailTable.COL_IS_LOW, item.getLow());
        db.insert(ItemDetailTable.TABLE, null, values);
        return item;
    }

    public Item updateItem(long itemId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        Item item = new Item();
        db.update(ItemDetailTable.TABLE, values,
                ItemDetailTable.COL_ITEM + " = ?", new String[]{item.getItem()});
        return item;
    }

    public void updateItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemDetailTable.COL_ITEM, item.getItem());
        values.put(ItemDetailTable.COL_DESCRIPTION, item.getDesc());
        values.put(ItemDetailTable.COL_AMOUNT, item.getQty());
        values.put(ItemDetailTable.COL_IS_LOW, item.getLow());
        db.update(ItemDetailTable.TABLE, values,
                ItemDetailTable.COL_ITEM + " = ?", new String[] { item.getItem() });

    }

    public void deleteItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemDetailTable.TABLE,
                ItemDetailTable.COL_ITEM + " = ?", new String[] { item.getItem() });

    }
    public void deleteItem(int id) {
        Item item = new Item(id);
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemDetailTable.TABLE,
                ItemDetailTable.COL_ID + " = ?", new String[] {String.valueOf(item.getId())});
    }
}