package com.zybooks.iqventory;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Splash Screen.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
@SuppressLint("CustomSplashScreen")
public class SplashScreen extends AppCompatActivity {

    /**
     * onCreate Method starts when the user is here.
     * Specifies which layout to use.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
    }

    /**
     * onClick Method is used to calculate clicks throughout the layout referenced in onCreate.
     *
     * This method determines if buttons are pressed and then sends you to the correct screen.
     */
    public void onClick(View view) {
        Button login = findViewById(R.id.login);
        Button signup = findViewById(R.id.signup);

        if (login.isPressed()) {
            startActivity(new Intent(SplashScreen.this,
                    LoginFormActivity.class));
        }

        if (signup.isPressed()) {
            startActivity(new Intent(SplashScreen.this,
                    SignupFormActivity.class));
        }
    }

}