package com.zybooks.iqventory;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * Item Activity Java Class.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class ItemActivity extends AppCompatActivity
        implements ItemDialogFragment.OnItemEnteredListener {

    private UsersDatabase usersDb;
    private int[] mItemColors;

    /**
     * onCreate Method starts when the user is here.
     * Specifies which layout to use.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        mItemColors = getResources().getIntArray(R.array.itemColors);

        // Singleton
        usersDb = UsersDatabase.getInstance(getApplicationContext());

        RecyclerView mRecyclerView = findViewById(R.id.itemRecyclerView);

        // Create 2 grid layout columns
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        // Shows the available items
        ItemAdapter mItemAdapter = new ItemAdapter(loadItems());
        mRecyclerView.setAdapter(mItemAdapter);
    }

    /**
     * This method listens for when an item is entered into the database.
     */
    @Override
    public void onItemEntered(String item) {
        // Returns item entered in the ItemDialogFragment dialog
        if (item.length() > 0) {
            Item ite = new Item();
            if (usersDb.addItem(ite)) {
                usersDb.addItem(ite);

                Toast.makeText(this, "Added " + item, Toast.LENGTH_SHORT).show();
            } else {
                String message = getResources().getString(R.string.item_exists, item);
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * This method adds an item.
     */
    public void addItemClick(View view) {
        // Prompt user to type new item
        FragmentManager manager = getSupportFragmentManager();
        ItemDialogFragment dialog = new ItemDialogFragment();
        dialog.show(manager, "itemDialogFragment");
    }

    /**
     * This method sorts items in the database.
     */
    private List<Item> loadItems() {
        return usersDb.getItems(UsersDatabase.ItemSortOrder.UPDATE_DESC);
    }

    /**
     * This method adds an item.
     */
    private class ItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener{

        private Item mItem;
        private final TextView mTextView;

        /**
         * This method holds items.
         */
        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mTextView = itemView.findViewById(R.id.itemTextView);
        }

        /**
         * This method binds a color to the items.
         */
        public void bind(Item item) {
            mItem = item;
            mTextView.setText(item.getItem());

            // Make the background color dependent on the length of the item string
            int colorIndex = item.getItem().length() % mItemColors.length;
            mTextView.setBackgroundColor(mItemColors[colorIndex]);
        }

        /**
         * onCreate Method starts when the user is here.
         * Specifies which layout to use.
         */
        @Override
        public void onClick(View view) {
            // Start QuestionActivity, indicating what subject was clicked
            Intent intent = new Intent(ItemActivity.this, ItemCountEdit.class);
            intent.putExtra(ItemCountEdit.EXTRA_ITEM, mItem.getItem());
            startActivity(intent);
        }
    }

    /**
     * ItemAdapter Class for adding items to the recycler.
     */
    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> mItemList;

        public ItemAdapter(List<Item> items) {
            mItemList = items;
        }

        /**
         * This method creates the view holder.
         */
        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new ItemHolder(layoutInflater, parent);
        }

        /**
         * This method binds a view holder.
         */
        @Override
        public void onBindViewHolder(ItemHolder holder, int position){
            holder.bind(mItemList.get(position));
        }

        /**
         * Returns item list count.
         */
        @Override
        public int getItemCount() {
            return mItemList.size();
        }
    }
}
