package com.zybooks.iqventory;

/**
 * Class to create a user in the database.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class User {

    int id;
    static String user_phone;
    static String user_name;
    static String user_pass;

    // constructor
    public User(String phone, String name, String password) {
        user_phone = phone;
        user_name = name;
        user_pass = password;
    }
    /**
     * Function for retrieval of actual username string.
     */
    public static String retrieveUser(String toString) {
        return getUserName();
    }

    /**
     * Function for retrieval of actual phone number string.
     */
    public static String getUserPhoneString(String user) {
        return getUserPhone();
    }

    /**
     * Returns user id.
     */
    public int getId() {
        return id;
    }

    /**
     * Sets user id.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns user phone number.
     */
    public static String getUserPhone() {
        return user_phone;
    }

    /**
     * Sets user phone number.
     */
    public void setUserPhone(String phone) {
        user_phone = phone;
    }

    /**
     * Returns user username.
     */
    public static String getUserName() {
        return user_name;
    }

    /**
     * Sets user username.
     */
    public void setUserName(String name) {
        user_name = name;
    }

    /**
     * Returns user password.
     */
    public static String getUserPass() {
        return user_pass;
    }

    /**
     * Sets user password.
     */
    public void setUserPass(String pass) {
        user_pass = pass;
    }
}
