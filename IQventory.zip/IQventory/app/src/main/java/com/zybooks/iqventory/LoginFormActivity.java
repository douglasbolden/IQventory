package com.zybooks.iqventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Login Form.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class LoginFormActivity extends AppCompatActivity {

    /**
     * onCreate Method starts when the user is here.
     * Specifies which layout to use.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);
    }

    /**
     * onClick Method is used to calculate clicks throughout the layout referenced in onCreate.
     *
     * This method allows the user to sign in, and checks if the user is in the users SQLite database.
     */
    public void onClick(View view) {
        Button login = findViewById(R.id.loginButton);
        EditText username = findViewById(R.id.username);
        EditText password = findViewById(R.id.password);

        UsersDatabase db = new UsersDatabase(getApplicationContext());
        if (login.isPressed()) {
            if (db.checkUserAndPass(username, password)) {
                username.getText().clear();
                password.getText().clear();
                password.setHintTextColor(getColor(R.color.accent));
                Intent intent = new Intent(LoginFormActivity.this,
                        MainActivity.class);
                intent.putExtra("user", User.retrieveUser(username.getText().toString()));
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Login Successful.", Toast.LENGTH_SHORT).show();
            }
            else {
                username.getText().clear();
                password.getText().clear();
                password.setHintTextColor(getColor(R.color.incorrect));
                Toast.makeText(getApplicationContext(), "Username or Password incorrect.", Toast.LENGTH_LONG).show();
            }
        }
    }
}