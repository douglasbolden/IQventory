package com.zybooks.iqventory;

import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

/**
 * Item Dialog Builder.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class ItemDialogFragment extends DialogFragment {

    // Host activity must implement
    public interface OnItemEnteredListener {
        void onItemEntered(String item);
    }

    private OnItemEnteredListener mListener;

    /**
     * This method is called when a dialog is created where it is specified.
     * This is what is used to give the users options to update the items.
     */
    @NonNull
    @Override
    public AlertDialog onCreateDialog(Bundle savedInstanceState) {

        final EditText itemEditText = new EditText(getActivity());
        itemEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        itemEditText.setMaxLines(1);

        return new AlertDialog.Builder(requireActivity())
                .setTitle(R.string.item)
                .setView(itemEditText)
                .setPositiveButton(R.string.create, (dialog, whichButton) -> {
                    String item = itemEditText.getText().toString();
                    mListener.onItemEntered(item.trim());
                })
                .setNegativeButton(R.string.cancel, null)
                .create();
    }

    /**
     * This method attaches the listener to the setPositiveButton function in onCreateDialog.
     */
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (OnItemEnteredListener) context;
    }
}