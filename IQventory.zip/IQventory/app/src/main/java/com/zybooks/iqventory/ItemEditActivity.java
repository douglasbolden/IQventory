package com.zybooks.iqventory;

import android.content.Intent;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 * Item Edit Activity.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class ItemEditActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM_ID = "com.zybooks.iqventory.item_id";
    public static final String EXTRA_ITEM = "com.zybooks.iqventory.item";

    private EditText itemText;

    private UsersDatabase usersDb;
    private long itemId;
    private Item item;

    /**
     * onCreate Method starts when the user is here.
     * Specifies which layout to use.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_count_edit);
        itemText = findViewById(R.id.itemCountText);

        usersDb = UsersDatabase.getInstance(getApplicationContext());

        // Get Item ID from ItemActivity
        Intent intent = getIntent();
        itemId = intent.getLongExtra(EXTRA_ITEM_ID, -1);

        ActionBar actionBar = getSupportActionBar();

        if (itemId == -1) {
            // Add new item
            item = new Item();
            setTitle(R.string.add_itemCount);
        }
        else {
            // Update existing item
            item = usersDb.updateItem(itemId);
            itemText.setText(item.getItem());
            setTitle(R.string.update_itemCount);
        }

        String it = intent.getStringExtra(EXTRA_ITEM);
        item.setItem(it);
    }

    /**
     * This method adds of updates the item in question.
     */
    public void saveButtonClick(View view) {

        item.setItem(itemText.getText().toString());

        if (itemId == -1) {
            // New item
            usersDb.addItem(item);
        } else {
            // Existing item
            usersDb.updateItem(item);
        }

        // Send back item ID
        Intent intent = new Intent();
        intent.putExtra(EXTRA_ITEM_ID, item.getId());
        setResult(RESULT_OK, intent);
        finish();
    }
}