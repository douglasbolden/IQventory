package com.zybooks.iqventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Signup Form.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class SignupFormActivity extends AppCompatActivity {

    /**
     * onCreate Method starts when the user is here.
     * Specifies which layout to use.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_form);
    }

    /**
     * onClick Method is used to calculate clicks throughout the layout referenced in onCreate.
     *
     * This method determines if the sign up button is pressed and then sends you to the correct screen.
     */
    public void onClick(View view) {
        Button signup = findViewById(R.id.createAccount);
        EditText username = findViewById(R.id.username_signup);
        EditText phone = findViewById(R.id.phone);
        EditText password = findViewById(R.id.password_signup);
        EditText confirmPassword = findViewById(R.id.confirm_password_signup);
        UsersDatabase db = new UsersDatabase(getApplicationContext());

        if (signup.isPressed()) {

            if (username.getText().toString().isEmpty() || password.getText().toString().isEmpty() || confirmPassword.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "Nothing is happening. Try hitting a few more buttons this time.", Toast.LENGTH_SHORT).show();
            }

            else if (password.getText().toString().equals(confirmPassword.getText().toString())) {

                if (!db.checkUser(username)) {
                    User newUser = new User(phone.getText().toString(), username.getText().toString(), password.getText().toString());
                    db.addUser(newUser);
                    Toast.makeText(getApplicationContext(), "Account Created Successfully.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignupFormActivity.this,
                            LoginFormActivity.class));
                }

                else {
                    username.getText().clear();
                    username.setHintTextColor(Color.rgb(255, 50, 50));
                    phone.getText().clear();
                    password.getText().clear();
                    password.setHintTextColor(getColor(R.color.incorrect));
                    confirmPassword.getText().clear();
                    confirmPassword.setHintTextColor(getColor(R.color.incorrect));
                    Toast.makeText(getApplicationContext(), "Username Already Registered.", Toast.LENGTH_SHORT).show();
                }
            }

            else {
                username.getText().clear();
                phone.getText().clear();
                password.getText().clear();
                password.setHintTextColor(getColor(R.color.incorrect));
                confirmPassword.getText().clear();
                confirmPassword.setHintTextColor(getColor(R.color.incorrect));
                Toast.makeText(getApplicationContext(), "Passwords do not match.", Toast.LENGTH_SHORT).show();
            }
        }
    }

}