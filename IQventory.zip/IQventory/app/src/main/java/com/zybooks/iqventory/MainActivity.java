package com.zybooks.iqventory;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Main Screen. This is where you go after you log in!
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class MainActivity extends AppCompatActivity {

    // Variables for SMS permissions
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static final String PERMISSION_SEND_SMS = android.Manifest.permission.SEND_SMS;

    /**
     * onCreate Method starts when the user is here.
     * Specifies which layout to use.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * The method shows the menu at the top of the screen. This menu contains the SMS button.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.item_menu, menu);
        return true;
    }

    /**
     * onClick Method is used to calculate clicks throughout the layout referenced in onCreate.
     *
     * This method determines if the SMS Button has permission to send you a text. If it has the
     * permission, it will send a text to the user.
     */
    public void onClick(MenuItem menuItem) {

        if (checkPermission()) {
            sendSMSMessage();
        }
        else {
            ActivityCompat.requestPermissions(this,
                    new String[]{PERMISSION_SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS);
        }
    }

    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(this, MainActivity.PERMISSION_SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    protected void sendSMSMessage() {
        Intent intent = getIntent();
        String user = intent.getStringExtra("user");
        String phone = User.getUserPhoneString(user);
        String message = "One of your items requires your attention.";
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phone, null, message, null, null);
        Toast.makeText(getApplicationContext(), "SMS sent.",
                Toast.LENGTH_LONG).show();
    }

    /**
     * onClick Method is used to calculate clicks throughout the layout referenced in onCreate.
     *
     * This method actually asks the user for permission to send SMS texts.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_PERMISSIONS_REQUEST_SEND_SMS) {

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSMSMessage();
            }
            else {
                Toast.makeText(getApplicationContext(),
                        "SMS Privileges declined. If you would like to enable them, please press the button again.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
