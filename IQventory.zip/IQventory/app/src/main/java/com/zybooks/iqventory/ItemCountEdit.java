package com.zybooks.iqventory;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

import java.util.List;

/**
 * Item Count Edit.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
@SuppressWarnings("ALL")
public class ItemCountEdit extends AppCompatActivity {

    private final int REQUEST_CODE_NEW_ITEM = 0;
    private final int REQUEST_CODE_UPDATE_ITEM = 1;
    public static final String EXTRA_ITEM = "com.zybooks.iqventory.item";

    private String item;
    private List<Item> itemList;
    private TextView itemText;
    private Item deletedItem;
    private int currentItemIndex;
    UsersDatabase usersDb = UsersDatabase.getInstance(getApplicationContext());

    /**
     * onCreate Method starts when the user is here.
     * Specifies which layout to use.
     */
    @SuppressLint("MissingInflatedId")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        // Hosting activity provides the item of the items to display
        Intent intent = getIntent();
        item = intent.getStringExtra(EXTRA_ITEM);

        // Load all items for this item
        itemList = usersDb.getItems(UsersDatabase.ItemSortOrder.valueOf(item));

        itemText = findViewById(R.id.editCountText);

        // Show first item
        showItem(0);
    }

    /**
     * This method shows the items.
     */
    @Override
    protected void onStart() {
        super.onStart();

        // Are there items to display?
        if (itemList.size() == 0) {
            updateAppBarTitle();
            displayItem(false);
        } else {
            displayItem(true);
        }
    }
    /**
     * This method creates the options menu at the top of the screen.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate menu for the app bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.item_menu, menu);
        return true;
    }

    /**
     * This method listens to which button in the list is selected.
     */
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Determine which app bar item was chosen
        switch (item.getItemId()) {
            case R.id.minus:
                showItem(currentItemIndex - 1);
                return true;
            case R.id.add:
                showItem(currentItemIndex + 1);
                return true;
            case R.id.saveButton:
                addItem();
                return true;
            case R.id.edit:
                editItem();
                return true;
            case R.id.delete:
                deleteItem();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void displayItem(boolean display) {
    }

    /**
     * This method allows the menu to change when conditions are met.
     */
    private void updateAppBarTitle() {

        // Display item and item details in app bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            @SuppressLint({"StringFormatInvalid", "LocalSuppress"}) String title = getResources().getString(R.string.item_number,
                    item, currentItemIndex + 1, itemList.size());
            setTitle(title);
        }
    }

    /**
     * This method adds an item.
     */
    private void addItem() {
        Intent intent = new Intent(this, ItemEditActivity.class);
        intent.putExtra(ItemEditActivity.EXTRA_ITEM, item);
        startActivityForResult(intent, REQUEST_CODE_NEW_ITEM);
    }

    /**
     * This method edits an item.
     */
    private void editItem() {
        if (currentItemIndex >= 0) {
            Intent intent = new Intent(this, ItemEditActivity.class);
            intent.putExtra(EXTRA_ITEM, item);
            int itemId = itemList.get(currentItemIndex).getId();
            intent.putExtra(ItemEditActivity.EXTRA_ITEM_ID, itemId);
            startActivityForResult(intent, REQUEST_CODE_UPDATE_ITEM);
        }
    }

    /**
     * This method shows the results of activities that the user performs.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_NEW_ITEM) {
            // Get added item
            int itemId = data.getIntExtra(ItemEditActivity.EXTRA_ITEM_ID, -1);
            Item newItem = usersDb.addItem(itemId);

            // Add newly created item to the item list and show it
            itemList.add(newItem);
            showItem(itemList.size() - 1);

            Toast.makeText(this, R.string.item_added, Toast.LENGTH_SHORT).show();
        }
        else if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_UPDATE_ITEM) {
            // Get updated item
            int itemId = data.getIntExtra(ItemEditActivity.EXTRA_ITEM_ID, -1);
            Item updatedItem = usersDb.addItem(itemId);

            // Replace current item in item list with updated item
            Item currentItem = itemList.get(currentItemIndex);
            currentItem.setItem(updatedItem.getItem());
            showItem(currentItemIndex);

            Toast.makeText(this, R.string.item_updated, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * This method deletes an item.
     */
    private void deleteItem() {
        if (currentItemIndex >= 0) {
            // Save item in case user undoes delete
            deletedItem = itemList.get(currentItemIndex);

            usersDb.deleteItem(deletedItem.getId());
            int itemId = itemList.get(currentItemIndex).getId();
            usersDb.deleteItem(itemId);
            itemList.remove(currentItemIndex);

            if (itemList.size() == 0) {
                // No items left to show
                currentItemIndex = -1;
                updateAppBarTitle();
                displayItem(false);
            }
            else {
                showItem(currentItemIndex);
            }

            // Show delete message with Undo button
            Snackbar snackbar = Snackbar.make(findViewById(R.id.constraintLayout),
                    R.string.item_deleted, Snackbar.LENGTH_LONG);
            snackbar.setAction(R.string.undo, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Add question back
                    usersDb.addItem(deletedItem);
                    itemList.add(deletedItem);
                    showItem(itemList.size() - 1);
                    displayItem(true);
                }
            });
            snackbar.show();
        }
    }

    /**
     * This method shows an item.
     */
    private void showItem(int itemIndex) {
        if (itemList.size() > 0) {

            if (itemIndex < 0) {
                itemIndex = itemList.size() - 1;
            }

            else if (itemIndex >= itemList.size()) {
                itemIndex = 0;
            }

            currentItemIndex = itemIndex;
            updateAppBarTitle();

            Item item = itemList.get(currentItemIndex);
            itemText.setText(item.getItem());
        }

        else {
            // No items yet
            currentItemIndex = -1;
        }
    }
}
