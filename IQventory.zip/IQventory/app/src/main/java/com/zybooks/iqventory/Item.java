package com.zybooks.iqventory;

 /**
 * Class to create an item in the database.
 *
 * Douglas Bolden
 * <i>douglas.bolden@ymail.com</i>
 */
public class Item {

    int id;
    String item;
    String desc;
    int qty;
    int low;

     // constructor
    public Item(int i, String item, String description, int quantity, int low) {
        super();
        this.id = i;
        this.item = item;
        this.desc = description;
        this.qty = quantity;
        this.low = low;
    }

    // constructor
    public Item(String item, String description, int quantity, int low) {
        this.item = item;
        this.desc = description;
        this.qty = quantity;
        this.low = low;
    }

     // constructor
    public Item(String item) {
        this.item = item;
    }

     // constructor
    public Item() {
         super();
    }

     public Item(int id) {
        this.id = id;
     }

     /**
      * Returns item id.
      */
    public int getId() {
        return id;
    }

     /**
      * Sets item id.
      */
    public void setId(int id) {
        this.id = id;
    }

     /**
      * Returns item name.
      */
    public String getItem() {
        return item;
    }

     /**
      * Sets item name.
      */
    public void setItem(String item) {
        this.item = item;
    }

     /**
      * Returns item description.
      */
    public String getDesc() {
        return desc;
    }

     /**
      * Sets item description.
      */
    public void setDesc(String desc) {
        this.desc = desc;
    }

     /**
      * Returns boolean for if item is low in stock.
      */
    public int getLow() {
        return low;
    }

     /**
      * Sets boolean for if item is low in stock.
      */
    public void setLow(int low) {
        this.low = low;
    }

     /**
      * Returns item quantity.
      */
    public int getQty() {
        return qty;
    }

     /**
      * Sets item quantity.
      */
    public void setQty(int qty) {
        this.qty = qty;
    }
 }
